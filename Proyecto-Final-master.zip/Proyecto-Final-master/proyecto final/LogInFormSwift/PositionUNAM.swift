//
//  PositionUNAM.swift
//  LogInFormSwift
//
//  Created by Usuario invitado on 11/30/18.
//  Copyright © 2018 Eng Tian Xi. All rights reserved.
//

import Foundation
import MapKit

class UnamAnnotation :MKPointAnnotation {
    
    var imageURL :String!
}
