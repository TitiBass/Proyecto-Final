//
//  Materias.swift
//  LogInFormSwift
//
//  Created by Usuario invitado on 25/10/18.
//  Copyright © 2018 Eng Tian Xi. All rights reserved.
//

import Foundation
struct horario{
    var materia: String
    var profesor: String
    var horario: String
    var salon: String
    var dias: String

}
