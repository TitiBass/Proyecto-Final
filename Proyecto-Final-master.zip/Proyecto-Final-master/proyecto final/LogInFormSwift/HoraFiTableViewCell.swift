//
//  HoraFiTableViewCell.swift
//  LogInFormSwift
//
//  Created by Usuario invitado on 25/10/18.
//  Copyright © 2018 Eng Tian Xi. All rights reserved.
//

import UIKit

class HoraFiTableViewCell: UITableViewCell {
@IBOutlet weak var labelCell: UILabel!
    @IBOutlet weak var classday: UILabel!
    @IBOutlet weak var classhrs: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
